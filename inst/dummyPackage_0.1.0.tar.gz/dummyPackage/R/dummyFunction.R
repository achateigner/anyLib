#' @title Prints Hello World!
#'
#' @description A light package to use as a dummy and light example
#' @return The sentence "Hello, world!
#' @examples
#' dummyFunction()
#' @export
dummyFunction <- function() {
  print("Hello, world!")
}
